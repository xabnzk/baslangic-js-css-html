var input_Giris = prompt("Giris Miladi:");

var ilk_asama = input_Giris-621;
var ikinci_asama = ilk_asama/33;
var ucuncu_asama = ilk_asama+ikinci_asama;

console.log(ucuncu_asama)

alert("Sonuc :"+ ucuncu_asama.toFixed(0))
